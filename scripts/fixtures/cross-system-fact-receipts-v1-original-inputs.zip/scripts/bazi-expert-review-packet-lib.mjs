import { createHash } from "node:crypto";
import { readFile, realpath, stat } from "node:fs/promises";
import path from "node:path";
import { verifyBaziEngineeringBindingCandidateLedger } from "./bazi-engineering-binding-candidate-lib.mjs";

export const BAZI_EXPERT_REVIEW_PACKET_RELATIVE_PATH =
  "content/bazi-strength-expert-review-packet.v1.json";

const SHA256_PATTERN = /^[a-f0-9]{64}$/u;
const MAX_PACKET_BYTES = 1_000_000;
const MAX_ARTIFACT_BYTES = 5_000_000;

const EXPECTED_ARTIFACTS = Object.freeze([
  ["bazi-core-fact-engine", "packages/bazi-core/src/index.ts", "engineering_input_fact_contract"],
  ["bazi-current-chart-fact-projection", "packages/bazi-interpretation/src/current-chart-review-snapshot.ts", "engineering_input_fact_contract"],
  ["bazi-strength-assessment-core", "packages/bazi-interpretation/src/strength-assessment-core.ts", "engineering_rule_candidate"],
  ["bazi-strength-claim-registry", "packages/bazi-interpretation/src/strength-claim-registry.ts", "content_claim_candidate"],
  ["bazi-strength-policy", "packages/bazi-interpretation/src/strength-policy.ts", "engineering_rule_candidate"],
  ["bazi-strength-sensitivity-review", "packages/bazi-interpretation/src/strength-sensitivity-review.ts", "engineering_sensitivity_evidence"],
  ["contracts", "packages/contracts/src/index.ts", "engineering_input_contract"],
  ["rule-profiles", "packages/rule-profiles/src/index.ts", "engineering_input_policy"],
  ["engineering-binding-candidate-ledger", "content/bazi-strength-engineering-binding-candidates.v1.json", "engineering_candidate_not_frozen_rationale"],
  ["source-binding-candidate-ledger", "content/bazi-strength-source-binding-candidates.v1.json", "source_candidate_not_content_truth"],
  ["source-rights-candidate-ledger", "content/bazi-strength-source-rights-candidates.v1.json", "rights_observation_not_legal_conclusion"],
  ["single-chart-report-v1.7-frozen-golden", "packages/research-export/src/golden/single-chart-report.contract.v1.7.json", "engineering_report_contract"]
]);

const EXPECTED_BINDING_IDS = Object.freeze([
  "binding:core:derive-assessment",
  "binding:policy:factor-inclusion",
  "binding:policy:direction-map",
  "binding:policy:weights",
  "binding:policy:month-duplication",
  "binding:policy:thresholds",
  "binding:sensitivity:six-scenarios",
  "binding:dtt:month-command",
  "binding:smt-v5:relative-relations",
  "binding:smt-v10:whole-chart",
  "binding:yhzp:hidden-listing",
  "binding:zpzz:review-gates"
]);

const EXPECTED_INDEPENDENCE_CHECKLIST = Object.freeze([
  "same_institution_or_organization",
  "teacher_student_or_lineage_relationship",
  "family_or_household_relationship",
  "shared_commercial_interest",
  "rule_or_case_set_coauthorship",
  "shared_professional_service",
  "reporting_or_supervision_relationship",
  "prior_exposure_to_other_reviewer_conclusion",
  "shared_unpublished_source_or_case_material",
  "same_upstream_algorithm_or_textbook_dependency"
]);

const EXPECTED_DISAGREEMENTS = Object.freeze([
  ["school_divergence", "split_versioned_school_profiles"],
  ["input_semantics", "split_versioned_input_policies"],
  ["base_edition_or_source_identity", "keep_affected_bindings_unverified"],
  ["rule_interpretation", "preserve_parallel_interpretations_no_winner"],
  ["engineering_error", "correct_artifact_and_repeat_both_reviews"],
  ["high_risk_expression", "apply_conservative_expression_or_no_release"],
  ["cannot_decide", "defer"]
]);

const EXPECTED_UNRESOLVED_STRUCTURES = Object.freeze(["从格", "专旺", "化气", "合化", "刑冲", "调候", "大运流年"]);
const EXPECTED_EXCLUDED_SCOPES = Object.freeze([
  "ziwei_domain_truth",
  "western_astrology_domain_truth",
  "vedic_astrology_domain_truth",
  "rights_or_legal_adjudication",
  "engineering_release_readiness",
  "individual_fortune_prediction",
  "public_deployment_authorization"
]);
const EXPECTED_REVIEW_QUESTIONS = Object.freeze([
  Object.freeze({
    questionId: "month-command-hidden-stem-duplication",
    title: "月令主气与首位藏干重复计权",
    question: "月令主气与同一月支首位藏干是否应同时计权；若同时计权，边界依据是什么？"
  }),
  Object.freeze({
    questionId: "relative-factor-weighting",
    title: "月令、透干与藏干相对权重",
    question: "透干、首位藏干、其余藏干与月令之间应采用怎样的相对权重，哪些反例会推翻当前‘月令 4、透干 2、首位藏干 2、其余藏干 1’候选？"
  }),
  Object.freeze({
    questionId: "strength-band-thresholds",
    title: "旺衰五档阈值",
    question: "0.25、0.43、0.57、0.75 分档阈值是否有可复核案例集支持？"
  }),
  Object.freeze({
    questionId: "strength-invalidation-structures",
    title: "基础旺衰结论失效或改写条件",
    question: "从格、专旺、化气、合化、刑冲、调候等结构应在何时使基础旺衰结论失效或改写？"
  })
]);
const EXPECTED_ROLE_SEPARATION = Object.freeze([
  Object.freeze({
    roleId: "domain_expert",
    allowedScope: Object.freeze(["bazi_rule_interpretation", "school_profile", "counterexample_cases", "high_risk_expression_boundary"]),
    forbiddenScope: Object.freeze(["rights_legal_conclusion", "engineering_reproducibility_attestation", "public_release_authorization"])
  }),
  Object.freeze({
    roleId: "source_rights_reviewer",
    allowedScope: Object.freeze(["work_identity", "edition_identity", "carrier_identity", "license_evidence"]),
    forbiddenScope: Object.freeze(["bazi_domain_truth", "engineering_reproducibility_attestation", "public_release_authorization"])
  }),
  Object.freeze({
    roleId: "engineering_reproducibility_reviewer",
    allowedScope: Object.freeze(["input_lock", "algorithm_lock", "digest_reproduction", "test_evidence"]),
    forbiddenScope: Object.freeze(["bazi_school_truth", "rights_legal_conclusion", "public_release_authorization"])
  })
]);
const EXPECTED_PRIVATE_DOSSIER_FIELDS = Object.freeze([
  "legal_name", "contact_details", "credential_raw_evidence", "institution_raw_evidence",
  "review_history", "verification_process_raw_evidence"
]);
const EXPECTED_PUBLIC_BINDING_FIELDS = Object.freeze([
  "reviewerId", "displayNameOrControlledPseudonym", "verificationMethod", "credentialDigest",
  "verificationDate", "reviewScope", "evidenceType", "verifiedBy"
]);
const EXPECTED_PUBLIC_PROHIBITED_FIELDS = Object.freeze([
  "legalName", "email", "phone", "address", "governmentId", "rawCredentialDocument", "privateContactHandle"
]);
const EXPECTED_REVIEW_PROCESS_STEPS = Object.freeze([
  "freeze_input_rules_sources_rights_and_golden",
  "verify_reviewer_identity_credentials_scope_and_independence",
  "collect_expert_a_opinion_without_expert_b_opinion_access",
  "collect_expert_b_opinion_without_expert_a_opinion_access",
  "seal_and_preserve_both_original_opinions",
  "publish_parallel_agreement_and_disagreement_inventory",
  "collect_independent_supplements_if_needed",
  "issue_reconciliation_note_without_overwriting_originals"
]);

export class BaziExpertReviewPacketError extends Error {
  constructor(code, message, options) {
    super(message, options);
    this.name = "BaziExpertReviewPacketError";
    this.code = code;
  }
}

function fail(code, message) {
  throw new BaziExpertReviewPacketError(code, message);
}

function canonicalValue(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (Array.isArray(value)) return value.map(canonicalValue);
  if (value && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonicalValue(value[key])]));
  }
  fail("NON_CANONICAL_JSON", "专家审阅包只接受有限规范 JSON 值。");
}

export function canonicalStringifyExpertReviewPacket(value) {
  return JSON.stringify(canonicalValue(value));
}

export function computeExpertReviewPacketDigest(packet) {
  const { packetDigest: _packetDigest, ...unsigned } = packet;
  return createHash("sha256").update(canonicalStringifyExpertReviewPacket(unsigned), "utf8").digest("hex");
}

function assertExactKeys(value, keys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("PACKET_INVALID", `${label} 必须是对象。`);
  const actual = Object.keys(value).sort();
  const expected = [...keys].sort();
  if (JSON.stringify(actual) !== JSON.stringify(expected)) fail("PACKET_INVALID", `${label} 字段集合不匹配。`);
}

function assertExactArray(actual, expected, label) {
  if (!Array.isArray(actual) || JSON.stringify(actual) !== JSON.stringify(expected)) {
    fail("PACKET_INVALID", `${label} 必须保持固定顺序与内容。`);
  }
}

function assertCanonicalEqual(actual, expected, label) {
  if (canonicalStringifyExpertReviewPacket(actual) !== canonicalStringifyExpertReviewPacket(expected)) {
    fail("PACKET_INVALID", `${label} 必须保持固定内容。`);
  }
}

function safeWorkspaceFile(workspaceRoot, relativePath) {
  if (!/^[A-Za-z0-9][A-Za-z0-9._/-]{0,299}$/u.test(relativePath)
    || relativePath.includes("..") || relativePath.startsWith("/") || relativePath.includes("\\")) {
    fail("UNSAFE_ARTIFACT_PATH", `专家审阅包文件路径不安全：${relativePath}`);
  }
  const root = path.resolve(workspaceRoot);
  const absolute = path.resolve(root, ...relativePath.split("/"));
  if (!absolute.startsWith(`${root}${path.sep}`)) fail("UNSAFE_ARTIFACT_PATH", `专家审阅包文件路径越界：${relativePath}`);
  return absolute;
}

async function artifactSha256(workspaceRoot, relativePath) {
  const absolute = safeWorkspaceFile(workspaceRoot, relativePath);
  let actual;
  let metadata;
  try {
    [actual, metadata] = await Promise.all([realpath(absolute), stat(absolute)]);
  } catch (cause) {
    throw new BaziExpertReviewPacketError("ARTIFACT_MISSING", `专家审阅包冻结文件不存在：${relativePath}`, { cause });
  }
  const root = await realpath(path.resolve(workspaceRoot));
  if (!actual.startsWith(`${root}${path.sep}`) || !metadata.isFile() || metadata.size > MAX_ARTIFACT_BYTES) {
    fail("UNSAFE_ARTIFACT_PATH", `专家审阅包冻结目标必须是工作区内普通小文件：${relativePath}`);
  }
  return createHash("sha256").update(await readFile(actual)).digest("hex");
}

export async function readBaziExpertReviewPacket(workspaceRoot) {
  const absolute = safeWorkspaceFile(workspaceRoot, BAZI_EXPERT_REVIEW_PACKET_RELATIVE_PATH);
  const metadata = await stat(absolute);
  if (!metadata.isFile() || metadata.size > MAX_PACKET_BYTES) fail("PACKET_INVALID", "专家审阅包缺失或超过输入上限。");
  try {
    return JSON.parse(await readFile(absolute, "utf8"));
  } catch (cause) {
    throw new BaziExpertReviewPacketError("PACKET_INVALID", "专家审阅包不是有效 JSON。", { cause });
  }
}

function verifyStaticBoundary(packet) {
  assertExactKeys(packet, [
    "schemaVersion", "recordType", "packetId", "status", "createdAt", "releaseGovernance",
    "artifactLocks", "sourceLedgerBindings", "reviewScope", "reviewQuestions", "roleSeparation",
    "identityPrivacyPolicy", "independenceChecklist", "reviewerSlots", "reviewProcess",
    "disagreementPolicy", "automatedResolutionPolicy", "gateSummary", "doesNotEstablish", "packetDigest"
  ], "packet");
  if (packet.schemaVersion !== "1.0.0"
    || packet.recordType !== "bazi_strength_expert_review_packet_candidate"
    || packet.packetId !== "hakimi.bazi.strength.expert-review-packet/1.5.0"
    || packet.status !== "mechanically_bound_vacant_review_packet"
    || Number.isNaN(Date.parse(packet.createdAt))) {
    fail("PACKET_IDENTITY_INVALID", "专家审阅包身份或时间无效。");
  }

  assertExactKeys(packet.releaseGovernance, [
    "releaseIdentity", "targetSchema", "migrationId", "mutationEpochBoundary",
    "publicDeploymentAuthorized", "expertClaimsAuthorized"
  ], "releaseGovernance");
  const release = packet.releaseGovernance;
  if (release.releaseIdentity !== "legacy-v13" || release.targetSchema !== 13 || release.migrationId !== null
    || release.mutationEpochBoundary !== "preserved" || release.publicDeploymentAuthorized !== false
    || release.expertClaimsAuthorized !== false) {
    fail("RELEASE_BOUNDARY_VIOLATION", "专家审阅包不得改变 v13、mutation epoch 或发布授权边界。");
  }

  assertExactKeys(packet.reviewScope, ["systemId", "surfaceId", "surfaceVersion", "bindingIds", "unresolvedStructures", "excludedScopes"], "reviewScope");
  if (packet.reviewScope.systemId !== "bazi" || packet.reviewScope.surfaceId !== "single-chart-report"
    || packet.reviewScope.surfaceVersion !== "1.7.0") {
    fail("REVIEW_SCOPE_DRIFT", "专家审阅范围不得外推到其他体系或版本。");
  }
  assertExactArray(packet.reviewScope.bindingIds, EXPECTED_BINDING_IDS, "reviewScope.bindingIds");
  assertExactArray(packet.reviewScope.unresolvedStructures, EXPECTED_UNRESOLVED_STRUCTURES, "reviewScope.unresolvedStructures");
  assertExactArray(packet.reviewScope.excludedScopes, EXPECTED_EXCLUDED_SCOPES, "reviewScope.excludedScopes");
  assertCanonicalEqual(packet.reviewQuestions, EXPECTED_REVIEW_QUESTIONS, "reviewQuestions");
  assertCanonicalEqual(packet.roleSeparation, EXPECTED_ROLE_SEPARATION, "roleSeparation");
  assertExactArray(packet.independenceChecklist, EXPECTED_INDEPENDENCE_CHECKLIST, "independenceChecklist");
  assertExactArray(
    packet.disagreementPolicy.map((entry) => [entry.disagreementType, entry.requiredDisposition]),
    EXPECTED_DISAGREEMENTS,
    "disagreementPolicy"
  );

  const identity = packet.identityPrivacyPolicy;
  assertExactKeys(identity, ["privateDossier", "publicIdentityBindingFields", "publicPacketProhibitedFields"], "identityPrivacyPolicy");
  assertExactKeys(identity.privateDossier, ["repositoryStorageAllowed", "encryptedOfflineStorageRequired", "fields"], "identityPrivacyPolicy.privateDossier");
  if (identity.privateDossier.repositoryStorageAllowed !== false
    || identity.privateDossier.encryptedOfflineStorageRequired !== true) {
    fail("PRIVATE_IDENTITY_EXPOSURE", "真实身份原始材料必须保持仓外加密离线存储。");
  }
  assertExactArray(identity.privateDossier.fields, EXPECTED_PRIVATE_DOSSIER_FIELDS, "identityPrivacyPolicy.privateDossier.fields");
  assertExactArray(identity.publicIdentityBindingFields, EXPECTED_PUBLIC_BINDING_FIELDS, "identityPrivacyPolicy.publicIdentityBindingFields");
  assertExactArray(identity.publicPacketProhibitedFields, EXPECTED_PUBLIC_PROHIBITED_FIELDS, "identityPrivacyPolicy.publicPacketProhibitedFields");

  const prohibitedKeys = new Set(identity.publicPacketProhibitedFields);
  for (const slot of packet.reviewerSlots) {
    assertExactKeys(slot, [
      "slotId", "reviewerBinding", "identityVerificationState", "credentialVerificationState",
      "scopeVerificationState", "independenceVerificationState", "originalOpinionDigest",
      "originalOpinionStored", "submittedAt", "priorExposureToOtherOpinion", "status"
    ], `reviewerSlots.${slot.slotId ?? "unknown"}`);
    if (slot.reviewerBinding !== null || slot.identityVerificationState !== "absent"
      || slot.credentialVerificationState !== "absent" || slot.scopeVerificationState !== "absent"
      || slot.independenceVerificationState !== "absent" || slot.originalOpinionDigest !== null
      || slot.originalOpinionStored !== false || slot.submittedAt !== null
      || slot.priorExposureToOtherOpinion !== null || slot.status !== "vacant") {
      fail("FABRICATED_REVIEWER_EVIDENCE", "候选审阅包只能保留空席，不能伪造现实专家或意见。");
    }
    for (const key of Object.keys(slot)) {
      if (prohibitedKeys.has(key)) fail("PRIVATE_IDENTITY_EXPOSURE", `公开审阅包不得包含身份字段：${key}`);
    }
  }
  assertExactArray(packet.reviewerSlots.map((slot) => slot.slotId), ["domain-expert-a", "domain-expert-b"], "reviewerSlots");

  const process = packet.reviewProcess;
  assertExactKeys(process, [
    "steps", "sameQuestionSetRequired", "mutualDisclosureBeforeBothOpinionsSealedAllowed",
    "immutableOriginalOpinionsRequired", "supplementsMustBeSeparateRecords", "reconciliationMayOverwriteOriginals"
  ], "reviewProcess");
  assertExactArray(process.steps, EXPECTED_REVIEW_PROCESS_STEPS, "reviewProcess.steps");
  if (process.sameQuestionSetRequired !== true || process.mutualDisclosureBeforeBothOpinionsSealedAllowed !== false
    || process.immutableOriginalOpinionsRequired !== true || process.supplementsMustBeSeparateRecords !== true
    || process.reconciliationMayOverwriteOriginals !== false) {
    fail("REVIEW_PROCESS_VIOLATION", "双席独立审阅、原件封存和补充记录边界不得弱化。");
  }

  for (const [index, entry] of packet.disagreementPolicy.entries()) {
    assertExactKeys(entry, ["disagreementType", "requiredDisposition"], `disagreementPolicy.${index}`);
  }

  const resolution = packet.automatedResolutionPolicy;
  assertExactKeys(resolution, [
    "majorityVoteAllowed", "opinionAveragingAllowed", "generatedModelWinnerSelectionAllowed",
    "unresolvedDisagreementMayBeAdopted", "allowedUnresolvedDisposition"
  ], "automatedResolutionPolicy");
  if (resolution.majorityVoteAllowed !== false || resolution.opinionAveragingAllowed !== false
    || resolution.generatedModelWinnerSelectionAllowed !== false
    || resolution.unresolvedDisagreementMayBeAdopted !== false) {
    fail("AUTOMATED_EXPERT_RESOLUTION_FORBIDDEN", "专家分歧不得多数表决、平均或由生成模型选赢家。");
  }
  assertExactArray(resolution.allowedUnresolvedDisposition, ["defer", "reject"], "allowedUnresolvedDisposition");

  const gate = packet.gateSummary;
  assertExactKeys(gate, [
    "packetArtifactLocksVerified", "domainExpertsRequired", "reviewerSlotsOccupied", "identitiesVerified",
    "credentialsVerified", "scopesVerified", "independentExpertReviewsVerified", "sealedOriginalOpinions",
    "expertReviewBundleComplete", "contentTruthEstablished", "expertTruthEstablished",
    "rightsLegalConclusionEstablished", "releaseReady", "publicDeploymentAuthorized", "expertClaimsAuthorized"
  ], "gateSummary");
  const expectedGate = {
    packetArtifactLocksVerified: EXPECTED_ARTIFACTS.length,
    domainExpertsRequired: 2,
    reviewerSlotsOccupied: 0,
    identitiesVerified: 0,
    credentialsVerified: 0,
    scopesVerified: 0,
    independentExpertReviewsVerified: 0,
    sealedOriginalOpinions: 0,
    expertReviewBundleComplete: false,
    contentTruthEstablished: false,
    expertTruthEstablished: false,
    rightsLegalConclusionEstablished: false,
    releaseReady: false,
    publicDeploymentAuthorized: false,
    expertClaimsAuthorized: false
  };
  for (const [key, expected] of Object.entries(expectedGate)) {
    if (gate[key] !== expected) fail("GATE_PROMOTION_FORBIDDEN", `gateSummary.${key} 必须保持 ${expected}。`);
  }

  const requiredNonClaims = [
    "real_reviewer_identity", "reviewer_credentials", "reviewer_independence", "expert_opinion",
    "content_truth", "expert_truth", "rights_legal_conclusion", "cross_system_authority",
    "release_readiness", "public_release_authorization"
  ];
  assertExactArray(packet.doesNotEstablish, requiredNonClaims, "doesNotEstablish");
  if (!SHA256_PATTERN.test(packet.packetDigest) || packet.packetDigest !== computeExpertReviewPacketDigest(packet)) {
    fail("PACKET_DIGEST_MISMATCH", "专家审阅包摘要不匹配。");
  }
}

async function verifyArtifactLocks(workspaceRoot, packet) {
  if (!Array.isArray(packet.artifactLocks) || packet.artifactLocks.length !== EXPECTED_ARTIFACTS.length) {
    fail("ARTIFACT_LOCK_MISMATCH", "专家审阅包冻结文件数量不匹配。");
  }
  for (let index = 0; index < EXPECTED_ARTIFACTS.length; index += 1) {
    const lock = packet.artifactLocks[index];
    const [artifactId, relativePath, evidenceLayer] = EXPECTED_ARTIFACTS[index];
    assertExactKeys(lock, ["artifactId", "path", "sha256", "evidenceLayer"], `artifactLocks.${index}`);
    if (lock.artifactId !== artifactId || lock.path !== relativePath || lock.evidenceLayer !== evidenceLayer
      || !SHA256_PATTERN.test(lock.sha256)) {
      fail("ARTIFACT_LOCK_MISMATCH", `专家审阅包冻结项不匹配：${artifactId}`);
    }
    const actual = await artifactSha256(workspaceRoot, relativePath);
    if (actual !== lock.sha256) fail("ARTIFACT_DRIFT", `专家审阅包冻结文件已漂移：${relativePath}`);
  }
}

async function verifyLedgerBindings(workspaceRoot, packet) {
  assertExactKeys(packet.sourceLedgerBindings, [
    "engineeringBindingLedgerId", "engineeringBindingLedgerDigest",
    "sourceBindingLedgerId", "sourceBindingLedgerDigest", "sourceRightsLedgerId", "sourceRightsLedgerDigest"
  ], "sourceLedgerBindings");
  const engineeringLedger = JSON.parse(await readFile(
    safeWorkspaceFile(workspaceRoot, "content/bazi-strength-engineering-binding-candidates.v1.json"),
    "utf8"
  ));
  await verifyBaziEngineeringBindingCandidateLedger(workspaceRoot, engineeringLedger);
  const bindingLedger = JSON.parse(await readFile(safeWorkspaceFile(workspaceRoot, "content/bazi-strength-source-binding-candidates.v1.json"), "utf8"));
  const rightsLedger = JSON.parse(await readFile(safeWorkspaceFile(workspaceRoot, "content/bazi-strength-source-rights-candidates.v1.json"), "utf8"));
  const expected = {
    engineeringBindingLedgerId: engineeringLedger.ledgerId,
    engineeringBindingLedgerDigest: engineeringLedger.ledgerDigest,
    sourceBindingLedgerId: bindingLedger.ledgerId,
    sourceBindingLedgerDigest: bindingLedger.ledgerDigest,
    sourceRightsLedgerId: rightsLedger.ledgerId,
    sourceRightsLedgerDigest: rightsLedger.ledgerDigest
  };
  for (const [key, value] of Object.entries(expected)) {
    if (packet.sourceLedgerBindings[key] !== value) fail("LEDGER_BINDING_MISMATCH", `专家审阅包来源账绑定不匹配：${key}`);
  }
}

export async function verifyBaziExpertReviewPacket(workspaceRoot, packet) {
  verifyStaticBoundary(packet);
  await verifyArtifactLocks(workspaceRoot, packet);
  await verifyLedgerBindings(workspaceRoot, packet);
  return Object.freeze({
    packet,
    packetDigest: packet.packetDigest,
    artifactLocksVerified: packet.artifactLocks.length,
    reviewerSlotsOccupied: 0,
    independentExpertReviewsVerified: 0
  });
}
