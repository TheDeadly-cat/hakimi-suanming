export const CROSS_SYSTEM_COMPARISON_DRAFT_VERSION = "cross-system-readonly-comparison/0.2-draft" as const;

export const CROSS_SYSTEM_IDS = Object.freeze([
  "bazi",
  "ziwei-doushu",
  "western-astrology"
] as const);

export type CrossSystemId = (typeof CROSS_SYSTEM_IDS)[number];

const ARTIFACT_KIND_BY_SYSTEM = Object.freeze({
  bazi: "bazi_revision_summary",
  "ziwei-doushu": "ziwei_revision_summary",
  "western-astrology": "western_rule_artifact"
} as const);

export type CrossSystemArtifactKind = (typeof ARTIFACT_KIND_BY_SYSTEM)[CrossSystemId];

export type CrossSystemFrozenFactDraft = Readonly<{
  field: string;
  value: string;
  sourceRef?: string;
}>;

export type CrossSystemArtifactSummaryDraft = Readonly<{
  systemId: CrossSystemId;
  artifactKind: CrossSystemArtifactKind;
  label: string;
  frozenFacts: readonly CrossSystemFrozenFactDraft[];
  ruleIdentity: Readonly<{
    profileId: string;
    profileVersion: string;
    profileDigest?: string;
  }>;
  sourceRefs: readonly string[];
  boundary: Readonly<{
    productionEligible: false;
    expertTruthClaimed: false;
    successReceiptIssued: false;
  }>;
}>;

export type CrossSystemExplicitSubjectLinkDraft = Readonly<{
  label: string;
  confirmedByUser: true;
  removable: true;
}>;

export const CROSS_SYSTEM_OBSERVATION_PARTITIONS = Object.freeze([
  "convergences",
  "divergences",
  "inputSemanticConflicts",
  "schoolConflicts",
  "evidenceQualityDifferences",
  "nonComparableConcepts",
  "unresolvedQuestions"
] as const);

export type CrossSystemObservationPartition =
  (typeof CROSS_SYSTEM_OBSERVATION_PARTITIONS)[number];

export type CrossSystemObservationBasisDraft = Readonly<{
  systemId: CrossSystemId;
  basisType: "frozen_fact" | "rule_identity" | "source_reference" | "declared_concept";
  reference: string;
}>;

export type CrossSystemObservationDraft = Readonly<{
  observationId: string;
  title: string;
  systemIds: readonly CrossSystemId[];
  basisRefs: readonly CrossSystemObservationBasisDraft[];
  note: string;
  entryMode: "manual_explicit_entry_unverified";
  assessmentState: "unreviewed_observation";
  conceptEquivalenceClaimed: false;
  expertTruthClaimed: false;
  modelArbitrationUsed: false;
}>;

export type CrossSystemObservationInventoryDraft = Readonly<
  Record<CrossSystemObservationPartition, readonly CrossSystemObservationDraft[]>
>;

export type CrossSystemReadonlyComparisonDraft = Readonly<{
  schemaVersion: typeof CROSS_SYSTEM_COMPARISON_DRAFT_VERSION;
  envelopeVersion: 2;
  createdAt: string;
  systems: readonly CrossSystemArtifactSummaryDraft[];
  factsFrozen: true;
  noScoring: true;
  noWeighting: true;
  noMajorityVote: true;
  noModelArbitration: true;
  noAutoPersonMerge: true;
  noConceptEquivalenceInference: true;
  explicitSubjectLink: CrossSystemExplicitSubjectLinkDraft | null;
  observations: CrossSystemObservationInventoryDraft;
  contentSha256: string;
}>;

export type CrossSystemComparisonPayload = Omit<CrossSystemReadonlyComparisonDraft, "contentSha256">;

export type CrossSystemVerificationResult =
  | { ok: true; value: CrossSystemReadonlyComparisonDraft }
  | { ok: false; reasons: readonly string[] };

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>)
    .sort(([left], [right]) => left.localeCompare(right));
  return `{${entries.map(([key, child]) => `${JSON.stringify(key)}:${stableStringify(child)}`).join(",")}}`;
}

async function sha256Hex(input: string): Promise<string> {
  const bytes = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function calculateCrossSystemComparisonSha256Draft(
  payload: CrossSystemComparisonPayload
): Promise<string> {
  return sha256Hex(stableStringify(payload));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function nonEmptyBounded(value: unknown, max: number): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.length <= max;
}

function hasExactKeys(value: Record<string, unknown>, expected: readonly string[]): boolean {
  const actual = Object.keys(value).sort((left, right) => left.localeCompare(right, "en"));
  const required = [...expected].sort((left, right) => left.localeCompare(right, "en"));
  return actual.length === required.length
    && actual.every((key, index) => key === required[index]);
}

function requireExactKeys(
  value: Record<string, unknown>,
  expected: readonly string[],
  reasons: string[],
  label: string
): void {
  if (!hasExactKeys(value, expected)) reasons.push(`${label} must contain only the exact contract fields`);
}

function validateSummary(value: unknown, reasons: string[], systemIds: Set<CrossSystemId>): void {
  if (!isRecord(value)) {
    reasons.push("system summary must be an object");
    return;
  }
  requireExactKeys(
    value,
    ["systemId", "artifactKind", "label", "frozenFacts", "ruleIdentity", "sourceRefs", "boundary"],
    reasons,
    "system summary"
  );
  const systemId = value.systemId;
  if (typeof systemId !== "string" || !CROSS_SYSTEM_IDS.includes(systemId as CrossSystemId)) {
    reasons.push(`unknown or duplicate systemId: ${String(systemId)}`);
    return;
  }
  const id = systemId as CrossSystemId;
  if (systemIds.has(id)) reasons.push(`duplicate systemId: ${id}`);
  systemIds.add(id);

  if (value.artifactKind !== ARTIFACT_KIND_BY_SYSTEM[id]) {
    reasons.push(`${id} artifactKind must be ${ARTIFACT_KIND_BY_SYSTEM[id]}`);
  }
  if (!nonEmptyBounded(value.label, 80)) reasons.push(`${id} label must be a non-empty string <= 80 chars`);
  if (!Array.isArray(value.frozenFacts) || value.frozenFacts.length === 0) {
    reasons.push(`${id} frozenFacts must contain at least one fact`);
  } else {
    const fields = new Set<string>();
    for (const fact of value.frozenFacts) {
      if (!isRecord(fact) || !nonEmptyBounded(fact.field, 80) || !nonEmptyBounded(fact.value, 1_000)) {
        reasons.push(`${id} frozen fact must have field <= 80 and value <= 1000`);
        continue;
      }
      requireExactKeys(
        fact,
        fact.sourceRef === undefined ? ["field", "value"] : ["field", "value", "sourceRef"],
        reasons,
        `${id} frozen fact`
      );
      if (fields.has(fact.field)) reasons.push(`${id} frozen fact field duplicated: ${fact.field}`);
      fields.add(fact.field);
      if (fact.sourceRef !== undefined && !nonEmptyBounded(fact.sourceRef, 200)) {
        reasons.push(`${id} frozen fact sourceRef must be <= 200 chars`);
      }
    }
  }

  if (!isRecord(value.ruleIdentity)
    || !nonEmptyBounded(value.ruleIdentity.profileId, 100)
    || !nonEmptyBounded(value.ruleIdentity.profileVersion, 50)) {
    reasons.push(`${id} ruleIdentity must include non-empty profileId and profileVersion`);
  } else {
    requireExactKeys(
      value.ruleIdentity,
      value.ruleIdentity.profileDigest === undefined
        ? ["profileId", "profileVersion"]
        : ["profileId", "profileVersion", "profileDigest"],
      reasons,
      `${id} ruleIdentity`
    );
    if (value.ruleIdentity.profileDigest !== undefined
      && (typeof value.ruleIdentity.profileDigest !== "string"
        || !/^[a-f0-9]{64}$/u.test(value.ruleIdentity.profileDigest))) {
      reasons.push(`${id} ruleIdentity.profileDigest must be lowercase SHA-256`);
    }
  }

  if (!Array.isArray(value.sourceRefs)
    || value.sourceRefs.length > 50
    || value.sourceRefs.some((ref) => !nonEmptyBounded(ref, 200))
    || new Set(value.sourceRefs).size !== value.sourceRefs.length) {
    reasons.push(`${id} sourceRefs must be an array of <= 50 strings each <= 200 chars`);
  }

  if (!isRecord(value.boundary)
    || value.boundary.productionEligible !== false
    || value.boundary.expertTruthClaimed !== false
    || value.boundary.successReceiptIssued !== false) {
    reasons.push(`${id} boundary must keep productionEligible/expertTruthClaimed/successReceiptIssued false`);
  } else {
    requireExactKeys(
      value.boundary,
      ["productionEligible", "expertTruthClaimed", "successReceiptIssued"],
      reasons,
      `${id} boundary`
    );
  }
}

const OBSERVATION_ID_PATTERN = /^[a-z][a-z0-9._-]{2,99}$/u;
const UNSAFE_OBSERVATION_TEXT_PATTERN =
  /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u061c\u200b-\u200f\u202a-\u202e\u2060-\u2069\ufeff]/u;
const OBSERVATION_BASIS_TYPES = new Set([
  "frozen_fact",
  "rule_identity",
  "source_reference",
  "declared_concept"
]);

function safeObservationText(value: unknown, maximum: number): value is string {
  return nonEmptyBounded(value, maximum) && !UNSAFE_OBSERVATION_TEXT_PATTERN.test(value);
}

function validateObservationInventory(
  value: unknown,
  reasons: string[],
  summaryBySystem: ReadonlyMap<CrossSystemId, Record<string, unknown>>
): void {
  if (!isRecord(value)) {
    reasons.push("observations must be an object");
    return;
  }
  requireExactKeys(value, CROSS_SYSTEM_OBSERVATION_PARTITIONS, reasons, "observations");
  const observationIds = new Set<string>();
  let totalObservations = 0;

  for (const partition of CROSS_SYSTEM_OBSERVATION_PARTITIONS) {
    const entries = value[partition];
    if (!Array.isArray(entries) || entries.length > 25) {
      reasons.push(`${partition} must be an array with at most 25 observations`);
      continue;
    }
    totalObservations += entries.length;
    for (const [index, entry] of entries.entries()) {
      const label = `${partition}[${index}]`;
      if (!isRecord(entry)) {
        reasons.push(`${label} must be an object`);
        continue;
      }
      requireExactKeys(
        entry,
        [
          "observationId",
          "title",
          "systemIds",
          "basisRefs",
          "note",
          "entryMode",
          "assessmentState",
          "conceptEquivalenceClaimed",
          "expertTruthClaimed",
          "modelArbitrationUsed"
        ],
        reasons,
        label
      );

      if (typeof entry.observationId !== "string"
        || !OBSERVATION_ID_PATTERN.test(entry.observationId)
        || observationIds.has(entry.observationId)) {
        reasons.push(`${label} observationId is invalid or duplicated`);
      } else {
        observationIds.add(entry.observationId);
      }
      if (!safeObservationText(entry.title, 120)) reasons.push(`${label} title is invalid`);
      if (!safeObservationText(entry.note, 1_000)) reasons.push(`${label} note is invalid`);
      if (entry.entryMode !== "manual_explicit_entry_unverified"
        || entry.assessmentState !== "unreviewed_observation"
        || entry.conceptEquivalenceClaimed !== false
        || entry.expertTruthClaimed !== false
        || entry.modelArbitrationUsed !== false) {
        reasons.push(`${label} must remain an unreviewed manual observation with no equivalence, expert truth or model arbitration claim`);
      }

      const minimumSystems = partition === "unresolvedQuestions" ? 1 : 2;
      const listedSystems = Array.isArray(entry.systemIds) ? entry.systemIds : [];
      if (listedSystems.length < minimumSystems
        || listedSystems.length > CROSS_SYSTEM_IDS.length
        || new Set(listedSystems).size !== listedSystems.length
        || listedSystems.some((systemId) => (
          typeof systemId !== "string"
          || !CROSS_SYSTEM_IDS.includes(systemId as CrossSystemId)
          || !summaryBySystem.has(systemId as CrossSystemId)
        ))) {
        reasons.push(`${label} systemIds must reference ${minimumSystems}..3 unique included systems`);
      } else {
        const expectedOrder = [...listedSystems]
          .sort((left, right) => CROSS_SYSTEM_IDS.indexOf(left as CrossSystemId)
            - CROSS_SYSTEM_IDS.indexOf(right as CrossSystemId));
        if (expectedOrder.some((systemId, position) => systemId !== listedSystems[position])) {
          reasons.push(`${label} systemIds must follow canonical system order`);
        }
      }

      const bases = Array.isArray(entry.basisRefs) ? entry.basisRefs : [];
      if (bases.length < 1 || bases.length > 20) {
        reasons.push(`${label} basisRefs must contain 1..20 explicit references`);
        continue;
      }
      const basisKeys = new Set<string>();
      const basisSystems = new Set<CrossSystemId>();
      for (const [basisIndex, basis] of bases.entries()) {
        const basisLabel = `${label}.basisRefs[${basisIndex}]`;
        if (!isRecord(basis)) {
          reasons.push(`${basisLabel} must be an object`);
          continue;
        }
        requireExactKeys(basis, ["systemId", "basisType", "reference"], reasons, basisLabel);
        if (typeof basis.systemId !== "string"
          || !CROSS_SYSTEM_IDS.includes(basis.systemId as CrossSystemId)
          || !listedSystems.includes(basis.systemId)) {
          reasons.push(`${basisLabel} systemId must be listed by its observation`);
          continue;
        }
        const systemId = basis.systemId as CrossSystemId;
        basisSystems.add(systemId);
        if (typeof basis.basisType !== "string" || !OBSERVATION_BASIS_TYPES.has(basis.basisType)) {
          reasons.push(`${basisLabel} basisType is invalid`);
          continue;
        }
        if (!safeObservationText(basis.reference, 200)) {
          reasons.push(`${basisLabel} reference is invalid`);
          continue;
        }
        const basisKey = `${systemId}:${basis.basisType}:${basis.reference}`;
        if (basisKeys.has(basisKey)) reasons.push(`${basisLabel} duplicates an earlier basis reference`);
        basisKeys.add(basisKey);

        const summary = summaryBySystem.get(systemId);
        if (!summary) continue;
        if (basis.basisType === "frozen_fact") {
          const facts = Array.isArray(summary.frozenFacts) ? summary.frozenFacts : [];
          if (!facts.some((fact) => isRecord(fact) && fact.field === basis.reference)) {
            reasons.push(`${basisLabel} does not reference an included frozen fact`);
          }
        } else if (basis.basisType === "rule_identity") {
          const ruleIdentity = isRecord(summary.ruleIdentity) ? summary.ruleIdentity : null;
          const expected = ruleIdentity
            ? `${String(ruleIdentity.profileId)}@${String(ruleIdentity.profileVersion)}`
            : null;
          if (basis.reference !== expected) reasons.push(`${basisLabel} does not reference the exact rule identity`);
        } else if (basis.basisType === "source_reference") {
          if (!Array.isArray(summary.sourceRefs) || !summary.sourceRefs.includes(basis.reference)) {
            reasons.push(`${basisLabel} does not reference an included sourceRef`);
          }
        } else if (partition !== "nonComparableConcepts") {
          reasons.push(`${basisLabel} declared_concept is allowed only for nonComparableConcepts`);
        }
      }
      for (const systemId of listedSystems) {
        if (!basisSystems.has(systemId as CrossSystemId)) {
          reasons.push(`${label} must include at least one basis reference for ${String(systemId)}`);
        }
      }
    }
  }
  if (totalObservations > 100) reasons.push("observations cannot exceed 100 total entries");
}

export async function verifyCrossSystemReadonlyComparisonDraft(
  candidate: unknown
): Promise<CrossSystemVerificationResult> {
  const reasons: string[] = [];
  if (!isRecord(candidate)) {
    return { ok: false, reasons: ["comparison must be an object"] };
  }
  requireExactKeys(
    candidate,
    [
      "schemaVersion",
      "envelopeVersion",
      "createdAt",
      "systems",
      "factsFrozen",
      "noScoring",
      "noWeighting",
      "noMajorityVote",
      "noModelArbitration",
      "noAutoPersonMerge",
      "noConceptEquivalenceInference",
      "explicitSubjectLink",
      "observations",
      "contentSha256"
    ],
    reasons,
    "comparison"
  );
  if (candidate.schemaVersion !== CROSS_SYSTEM_COMPARISON_DRAFT_VERSION) {
    reasons.push("schemaVersion mismatch");
  }
  if (candidate.envelopeVersion !== 2) reasons.push("envelopeVersion must be 2");
  if (candidate.factsFrozen !== true) reasons.push("factsFrozen must be true");
  if (candidate.noScoring !== true) reasons.push("noScoring must be true");
  if (candidate.noWeighting !== true) reasons.push("noWeighting must be true");
  if (candidate.noMajorityVote !== true) reasons.push("noMajorityVote must be true");
  if (candidate.noModelArbitration !== true) reasons.push("noModelArbitration must be true");
  if (candidate.noAutoPersonMerge !== true) reasons.push("noAutoPersonMerge must be true");
  if (candidate.noConceptEquivalenceInference !== true) {
    reasons.push("noConceptEquivalenceInference must be true");
  }
  if (typeof candidate.createdAt !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/u.test(candidate.createdAt)) {
    reasons.push("createdAt must be a UTC ISO timestamp");
  }

  if (!Array.isArray(candidate.systems) || candidate.systems.length < 1 || candidate.systems.length > 3) {
    reasons.push("systems must contain 1..3 summaries");
  } else {
    const systemIds = new Set<CrossSystemId>();
    for (const summary of candidate.systems) validateSummary(summary, reasons, systemIds);
    const observedOrder = candidate.systems
      .map((summary) => isRecord(summary) ? summary.systemId : null)
      .filter((systemId): systemId is string => typeof systemId === "string");
    const canonicalOrder = [...observedOrder]
      .sort((left, right) => CROSS_SYSTEM_IDS.indexOf(left as CrossSystemId)
        - CROSS_SYSTEM_IDS.indexOf(right as CrossSystemId));
    if (canonicalOrder.some((systemId, index) => systemId !== observedOrder[index])) {
      reasons.push("systems must follow canonical system order");
    }
  }

  if (candidate.explicitSubjectLink === null) {
    // Explicitly no person link is allowed.
  } else if (!isRecord(candidate.explicitSubjectLink)
    || !safeObservationText(candidate.explicitSubjectLink.label, 80)
    || candidate.explicitSubjectLink.confirmedByUser !== true
    || candidate.explicitSubjectLink.removable !== true) {
    reasons.push("explicitSubjectLink must be null or a user-confirmed removable link with a label");
  } else {
    requireExactKeys(
      candidate.explicitSubjectLink,
      ["label", "confirmedByUser", "removable"],
      reasons,
      "explicitSubjectLink"
    );
  }

  const summaryBySystem = new Map<CrossSystemId, Record<string, unknown>>();
  if (Array.isArray(candidate.systems)) {
    for (const summary of candidate.systems) {
      if (isRecord(summary)
        && typeof summary.systemId === "string"
        && CROSS_SYSTEM_IDS.includes(summary.systemId as CrossSystemId)
        && !summaryBySystem.has(summary.systemId as CrossSystemId)) {
        summaryBySystem.set(summary.systemId as CrossSystemId, summary);
      }
    }
  }
  validateObservationInventory(candidate.observations, reasons, summaryBySystem);

  if (typeof candidate.contentSha256 !== "string" || !/^[a-f0-9]{64}$/u.test(candidate.contentSha256)) {
    reasons.push("contentSha256 must be lowercase SHA-256");
  } else {
    const { contentSha256: _expected, ...payload } = candidate;
    const actual = await calculateCrossSystemComparisonSha256Draft(
      payload as unknown as CrossSystemComparisonPayload
    );
    if (actual !== candidate.contentSha256) reasons.push("contentSha256 does not match canonical payload");
  }

  if (reasons.length) return { ok: false, reasons };
  return { ok: true, value: candidate as unknown as CrossSystemReadonlyComparisonDraft };
}
