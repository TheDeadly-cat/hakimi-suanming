import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  eventRecordSchema,
  type BirthInput,
  type CaseRecord,
  type EventRecord,
  type RevisionRecord,
  type RulePackBinding
} from "@hakimi/contracts";
import { calculateChart, digestRuleProfile } from "@hakimi/bazi-core";
import { WORKING_DEFAULT_RULE_PROFILE } from "@hakimi/rule-profiles";
import { calculatePillarRelations } from "@hakimi/relations-core";
import * as transitCore from "@hakimi/transit-core";
import {
  RESEARCH_JOURNAL_SNAPSHOT_PROFILE,
  caseRepository,
  researchRepository,
  type ResearchJournalSnapshot
} from "@hakimi/storage";
import { ChartPage, LuckCyclePanel, PillarRelationsPanel } from "./chart-page";
import { shortHash } from "../lib/format";
import { EXPERT_MODE_KEY } from "../lib/expert-mode";
import { navigate } from "../lib/router";
import { clearBootGovernanceFixture, installLegacyV13BootGovernance } from "../test/boot-governance-fixture";

beforeEach(() => {
  installLegacyV13BootGovernance();
  window.localStorage.clear();
});

afterEach(() => {
  vi.restoreAllMocks();
  clearBootGovernanceFixture();
  window.history.replaceState({}, "", "/");
  window.localStorage.clear();
});

const input: BirthInput = {
  schemaVersion: "1.0.0",
  calendarType: "gregorian",
  date: "1995-08-18",
  time: "08:26",
  timePrecision: "exact_minute",
  timeZone: "Asia/Shanghai",
  sex: "male",
  lunarLeapMonth: false,
  location: { label: "", latitude: null, longitude: null, precision: "unknown" },
  sourceNote: ""
};

async function revisionFor(birth: BirthInput, rulePackBinding?: RulePackBinding): Promise<RevisionRecord> {
  const chart = await calculateChart(birth, WORKING_DEFAULT_RULE_PROFILE, { rulePackBinding });
  return {
    schemaVersion: "1.0.0",
    id: "11111111-1111-4111-8111-111111111111",
    caseId: "22222222-2222-4222-8222-222222222222",
    revisionNumber: 1,
    createdAt: "2026-08-01T00:00:00.000Z",
    input: chart.input,
    timeCalibration: chart.timeCalibration,
    ruleProfile: chart.ruleProfile,
    facts: chart.facts,
    luckCycleRuleSnapshot: chart.luckCycleRuleSnapshot,
    ...(chart.rulePackBinding ? { rulePackBinding: chart.rulePackBinding } : {}),
    manifest: chart.manifest
  };
}

async function testRulePackBinding(): Promise<RulePackBinding> {
  return {
    kind: "installed_rule_pack",
    packDigest: "a".repeat(64),
    profileDigest: await digestRuleProfile(WORKING_DEFAULT_RULE_PROFILE),
    packId: "chart-page-test-pack",
    profileId: WORKING_DEFAULT_RULE_PROFILE.profileId,
    profileVersion: WORKING_DEFAULT_RULE_PROFILE.profileVersion,
    useMode: "exact"
  };
}

function mockResearchJournalSnapshot(caseId: string, events: readonly EventRecord[] = []) {
  const snapshot: ResearchJournalSnapshot = {
    caseId,
    profile: RESEARCH_JOURNAL_SNAPSHOT_PROFILE,
    notes: [],
    events,
    citationIndex: { status: "loaded", records: [] },
    receiptIndex: { status: "loaded", records: [] },
    boundary: {
      atomicStorageSnapshotVerified: true,
      caseIdBound: true,
      transactionMode: "readonly",
      mutationEpochRead: false,
      mutationEpochRevalidationPerformed: false,
      storageMutationPerformed: false,
      schemaOrReleaseIdentityMutationPerformed: false,
      expertTruthClaimed: false,
      publicReleaseAuthorized: false,
      formalActivationAllowed: false
    }
  };
  return vi.spyOn(researchRepository, "readResearchJournalSnapshot").mockResolvedValue(snapshot);
}

describe("LuckCyclePanel", () => {
  it("显示可审计起运事实与十个半开大运区间，不输出断语", async () => {
    render(<LuckCyclePanel revision={await revisionFor(input)} />);

    expect(screen.getByRole("heading", { name: "起运与十柱大运" })).toBeTruthy();
    expect(screen.getByText(/逆行 · 乙阴年干/)).toBeTruthy();
    expect(screen.getByText(/未舍入/)).toBeTruthy();
    const track = screen.getByRole("list", { name: "十柱大运半开区间" });
    expect(within(track).getAllByRole("listitem")).toHaveLength(10);
    expect(screen.getByText(/不输出吉凶、旺衰或事件预测/)).toBeTruthy();
  });

  it("性别未指定时要求人工方向，不静默猜测", async () => {
    render(<LuckCyclePanel revision={await revisionFor({ ...input, sex: "unspecified" })} />);

    expect(screen.getByText("性别未指定，不能静默决定顺逆")).toBeTruthy();
    expect(screen.queryByRole("list", { name: "十柱大运半开区间" })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "人工指定顺行" }));
    expect(screen.getByText(/顺行 · 乙阴年干/)).toBeTruthy();
    expect(within(screen.getByRole("list", { name: "十柱大运半开区间" })).getAllByRole("listitem")).toHaveLength(10);
  });
});

describe("PillarRelationsPanel", () => {
  it("只显示版本化干支关系事实，并保留完整度与待复核状态", async () => {
    const revision = await revisionFor(input);
    const expected = calculatePillarRelations(revision.facts);
    render(<PillarRelationsPanel revision={revision} />);

    expect(screen.getByRole("heading", { name: "干支关系事实" })).toBeTruthy();
    const list = screen.getByRole("list", { name: "干支关系事实列表" });
    expect(within(list).getAllByRole("listitem")).toHaveLength(expected.facts.length);
    expect(screen.getByText(/不判断合化、力量或吉凶/)).toBeTruthy();
    expect(screen.getAllByText(/待顾问/).length).toBeGreaterThan(0);
  });
});

describe("ChartPage transit route", () => {
  it("显示规则包、Profile 与双摘要的精确绑定来源", async () => {
    const binding = await testRulePackBinding();
    const revision = await revisionFor(input, binding);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "规则包来源案例",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id);
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${revision.id}?view=research`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    const metadataHeading = await screen.findByRole("heading", { name: "复算元数据" });
    const metadata = metadataHeading.closest("section");
    expect(metadata).not.toBeNull();
    expect(screen.getByText(binding.packId)).toBeTruthy();
    expect(screen.getByText(shortHash(binding.packDigest))).toBeTruthy();
    expect(screen.getByText(`${binding.profileId}@${binding.profileVersion} · 精确使用`)).toBeTruthy();
    expect(screen.getAllByText(shortHash(binding.profileDigest)).length).toBeGreaterThanOrEqual(1);
    expect(screen.queryByText("未绑定安装包 · 内置或派生规则快照")).toBeNull();
    expect(within(metadata!).queryByText("Case ID")).toBeNull();
    expect(within(metadata!).queryByText("Revision ID")).toBeNull();
    const exportBinding = await screen.findByLabelText("当前导出来源短标识");
    expect(within(exportBinding).getByText("案例短标识")).toBeTruthy();
    expect(within(exportBinding).getByText(shortHash(caseRecord.id))).toBeTruthy();
    expect(within(exportBinding).getByText("修订短标识")).toBeTruthy();
    expect(within(exportBinding).getByText(shortHash(revision.id))).toBeTruthy();
    expect(within(exportBinding).queryByText(caseRecord.id)).toBeNull();
    expect(within(exportBinding).queryByText(revision.id)).toBeNull();
  });

  it("专家模式显示完整摘要与 Case/Revision 原始标识", async () => {
    const binding = await testRulePackBinding();
    const revision = await revisionFor(input, binding);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "规则包来源案例",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id);
    window.localStorage.setItem(EXPERT_MODE_KEY, "1");
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${revision.id}?view=research`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    const metadataHeading = await screen.findByRole("heading", { name: "复算元数据" });
    const metadata = metadataHeading.closest("section");
    expect(metadata).not.toBeNull();
    expect(await screen.findByText(binding.packDigest)).toBeTruthy();
    expect((await screen.findAllByText(binding.profileDigest)).length).toBeGreaterThanOrEqual(1);
    expect(within(metadata!).getByText("Case ID")).toBeTruthy();
    expect(within(metadata!).getByText(revision.caseId)).toBeTruthy();
    expect(within(metadata!).getByText("Revision ID")).toBeTruthy();
    expect(within(metadata!).getByText(revision.id)).toBeTruthy();
    const exportBinding = await screen.findByLabelText("当前导出来源完整标识");
    expect(within(exportBinding).getByText(revision.caseId)).toBeTruthy();
    expect(within(exportBinding).getByText(revision.id)).toBeTruthy();
  });

  it("在研读页按派生复演、出生时间扰动、DeepSeek 的顺序展示且扰动默认不运行", async () => {
    const revision = await revisionFor(input);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "七点扰动入口案例",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id);
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${revision.id}?view=research`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    const derivedPanel = (await screen.findByRole("heading", { name: "显式版本派生投影" })).closest("section");
    const perturbationPanel = screen.getByRole("heading", { name: "出生时间扰动：七点四柱投影" }).closest("section");
    const deepSeekPanel = screen.getByRole("heading", { name: "本机 AI 断言草稿验证器" }).closest("section");
    expect(derivedPanel).not.toBeNull();
    expect(perturbationPanel).not.toBeNull();
    expect(deepSeekPanel).not.toBeNull();
    expect(derivedPanel!.compareDocumentPosition(perturbationPanel!) & Node.DOCUMENT_POSITION_FOLLOWING).not.toBe(0);
    expect(perturbationPanel!.compareDocumentPosition(deepSeekPanel!) & Node.DOCUMENT_POSITION_FOLLOWING).not.toBe(0);
    expect(perturbationPanel?.dataset.state).toBe("idle");
    expect(within(perturbationPanel!).getByRole("button", { name: "运行七点民用时间扰动" })).toBeTruthy();
    expect(within(perturbationPanel!).queryByRole("heading", { name: "七点扰动报告" })).toBeNull();
    expect(screen.queryByRole("alert")).toBeNull();
  });

  it("在研读页运行本命盘只读复演且不写入新 Revision", async () => {
    const revision = await revisionFor(input);
    const revisionBefore = structuredClone(revision);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "只读复演案例",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id);
    const addRevision = vi.spyOn(caseRepository, "addRevision");
    const listReceipts = vi.spyOn(caseRepository, "listRevisionCalculationReceipts");
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${revision.id}?view=research`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    expect(await screen.findByRole("heading", { name: "本命盘只读复演" })).toBeTruthy();
    const replayButton = await screen.findByRole("button", { name: "运行本命盘只读复演" });
    fireEvent.click(replayButton);
    expect(await screen.findByText("冻结结果与精确执行器复演一致", {}, { timeout: 10_000 })).toBeTruthy();
    expect(screen.getByText(/源 Revision 未改写/)).toBeTruthy();
    expect(addRevision).not.toHaveBeenCalled();
    expect(listReceipts).not.toHaveBeenCalled();
    expect(screen.queryByRole("heading", { name: "历史计算收据" })).toBeNull();
    expect(revision).toEqual(revisionBefore);
  }, 15_000);

  it("刷新可恢复运限视图，并把所选节点带到研读事件表单", async () => {
    const calculateTransit = vi.spyOn(transitCore, "calculateTransitSnapshot");
    const revision = await revisionFor(input);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "运限路由案例",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id);
    const pathname = `/cases/${caseRecord.id}/revisions/${revision.id}`;
    window.history.replaceState({}, "", `${pathname}?view=transit&at=2026-08-01T12%3A00%3A00Z&scale=day&track=year&track=month`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    expect(await screen.findByRole("heading", { name: "同一瞬时点的六层运限切片" })).toBeTruthy();
    const researchHref = new URL(screen.getByRole("link", { name: "研读" }).getAttribute("href")!, "https://hakimi.test");
    expect(researchHref.searchParams.get("scale")).toBe("day");
    expect(researchHref.searchParams.getAll("track")).toEqual(["year", "month"]);
    const yearSection = (await screen.findByRole("heading", { name: "流年" })).closest("section");
    fireEvent.click(within(yearSection!).getAllByRole("button")[0]);
    await waitFor(() => expect(window.location.search).toContain("node=year%3A"));

    const openResearch = await screen.findByRole("button", { name: "到研读页记录事件" }, { timeout: 10_000 });
    // Selecting the year moved the observation instant to that node's start.
    expect(calculateTransit).toHaveBeenCalledTimes(2);
    fireEvent.click(openResearch);
    expect(await screen.findByText(/绑定所选year节点/)).toBeTruthy();
    expect(calculateTransit).toHaveBeenCalledTimes(2);
    const researchParams = new URLSearchParams(window.location.search);
    expect(researchParams.get("scale")).toBe("day");
    expect(researchParams.getAll("track")).toEqual(["year", "month"]);

  });

  it("观察时刻、人工方向或 Revision 变化仍触发运限重算，离开上下文后重新进入也重算", async () => {
    const first = await revisionFor(input);
    const second: RevisionRecord = {
      ...first,
      id: "33333333-3333-4333-8333-333333333333",
      revisionNumber: 2
    };
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: first.caseId,
      alias: "运限计算依赖案例",
      tags: [],
      notes: "",
      createdAt: first.createdAt,
      updatedAt: second.createdAt,
      latestRevisionId: second.id,
      revisionCount: 2,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [first, second] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    // This fixture checks when calculation is requested; the route test above
    // retains the real calculator and verifies the selected node's UI binding.
    const calculateTransit = vi.spyOn(transitCore, "calculateTransitSnapshot")
      .mockRejectedValue(new Error("fixture calculation unavailable"));
    const pathname = `/cases/${caseRecord.id}/revisions/${first.id}`;
    window.history.replaceState({}, "", `${pathname}?view=transit&at=2026-08-01T12%3A00%3A00Z`);
    const page = render(<ChartPage caseId={caseRecord.id} revisionId={first.id} />);
    await waitFor(() => expect(calculateTransit).toHaveBeenCalledTimes(1));

    await act(async () => { navigate(`${pathname}?view=transit&at=2026-08-02T12%3A00%3A00Z`, { scroll: false }); });
    expect(calculateTransit).toHaveBeenCalledTimes(2);
    expect(calculateTransit).toHaveBeenLastCalledWith({ revision: first, atInstant: "2026-08-02T12:00:00Z" });

    await act(async () => { navigate(`${pathname}?view=transit&at=2026-08-02T12%3A00%3A00Z&dir=forward`, { scroll: false }); });
    expect(calculateTransit).toHaveBeenCalledTimes(3);
    expect(calculateTransit).toHaveBeenLastCalledWith({ revision: first, atInstant: "2026-08-02T12:00:00Z", manualDirection: "forward" });

    page.rerender(<ChartPage caseId={caseRecord.id} revisionId={second.id} />);
    await waitFor(() => expect(calculateTransit).toHaveBeenCalledTimes(4));
    expect(calculateTransit).toHaveBeenLastCalledWith({ revision: second, atInstant: "2026-08-02T12:00:00Z", manualDirection: "forward" });

    await act(async () => { navigate(`${pathname}?view=structure`, { scroll: false }); });
    expect(calculateTransit).toHaveBeenCalledTimes(4);
    await act(async () => { navigate(`${pathname}?view=transit&at=2026-08-02T12%3A00%3A00Z&dir=forward`, { scroll: false }); });
    expect(calculateTransit).toHaveBeenCalledTimes(5);
  });

  it("切换历史 Revision 时保留 view、at、scale 与 tracks，并清除 node、dir 和未知 query", async () => {
    const first = await revisionFor(input);
    const secondCalculated = await calculateChart({ ...input, date: "1995-08-19" }, WORKING_DEFAULT_RULE_PROFILE);
    const second: RevisionRecord = {
      schemaVersion: "1.0.0",
      id: "33333333-3333-4333-8333-333333333333",
      caseId: first.caseId,
      revisionNumber: 2,
      createdAt: "2026-08-02T00:00:00.000Z",
      input: secondCalculated.input,
      timeCalibration: secondCalculated.timeCalibration,
      ruleProfile: secondCalculated.ruleProfile,
      facts: secondCalculated.facts,
      luckCycleRuleSnapshot: secondCalculated.luckCycleRuleSnapshot,
      manifest: secondCalculated.manifest
    };
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: first.caseId,
      alias: "历史切换案例",
      tags: [],
      notes: "",
      createdAt: first.createdAt,
      updatedAt: second.createdAt,
      latestRevisionId: second.id,
      revisionCount: 2,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [first, second] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([]);
    const node = `year:1.${"a".repeat(64)}`;
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${first.id}?view=transit&at=2026-08-01T12%3A00%3A00Z&node=${encodeURIComponent(node)}&dir=forward&scale=hour&track=year&track=hour&unsafe=1`);

    render(<ChartPage caseId={caseRecord.id} revisionId={first.id} />);

    const history = await screen.findByRole("combobox", { name: "历史 Revision" });
    fireEvent.change(history, { target: { value: second.id } });

    expect(window.location.pathname).toBe(`/cases/${caseRecord.id}/revisions/${second.id}`);
    const params = new URLSearchParams(window.location.search);
    expect(params.get("view")).toBe("transit");
    expect(params.get("at")).toBe("2026-08-01T12:00:00Z");
    expect(params.get("scale")).toBe("hour");
    expect(params.getAll("track")).toEqual(["year", "hour"]);
    expect(params.has("node")).toBe(false);
    expect(params.has("dir")).toBe(false);
    expect(params.has("unsafe")).toBe(false);
  });

  it("research 事件 UUID 只在同案例同修订精确命中，并将卡片聚焦", async () => {
    const revision = await revisionFor(input);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "事件深链案例",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    const record = eventRecordSchema.parse({
      schemaVersion: "1.0.0",
      recordVersion: 2,
      id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
      caseId: caseRecord.id,
      revisionId: revision.id,
      transitNodeRef: null,
      datePrecision: "day",
      startDate: "2026-08-01",
      endDate: null,
      title: "深链精确事件",
      tags: [],
      sourceRefs: [],
      feedback: "unreviewed",
      bodyFormat: "markdown",
      body: "",
      timeContext: { kind: "calendar_date" },
      deletedAt: null,
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt
    });
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([record]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id, [record]);
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${revision.id}?view=research&event=${record.id}`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    const card = await screen.findByRole("article", { name: "事件 深链精确事件" });
    expect(screen.getByText("未绑定安装包 · 内置或派生规则快照")).toBeTruthy();
    expect(card.classList.contains("event-card--selected")).toBe(true);
    expect(screen.getByText("深链定位")).toBeTruthy();
    await waitFor(() => expect(document.activeElement).toBe(card));
    expect(screen.queryByRole("alert", { name: /无法定位事件/ })).toBeNull();
  });

  it("跨修订事件深链给出告警且绝不回退到近似事件", async () => {
    const first = await revisionFor(input);
    const second: RevisionRecord = { ...first, id: "33333333-3333-4333-8333-333333333333", revisionNumber: 2 };
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: first.caseId,
      alias: "跨修订事件",
      tags: [],
      notes: "",
      createdAt: first.createdAt,
      updatedAt: first.createdAt,
      latestRevisionId: second.id,
      revisionCount: 2,
      recordVersion: 2,
      favorite: false,
      deletedAt: null
    };
    const record = eventRecordSchema.parse({
      schemaVersion: "1.0.0",
      recordVersion: 2,
      id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
      caseId: caseRecord.id,
      revisionId: second.id,
      transitNodeRef: null,
      datePrecision: "day",
      startDate: "2026-08-02",
      endDate: null,
      title: "其他修订事件",
      tags: [],
      sourceRefs: [],
      feedback: "unreviewed",
      bodyFormat: "markdown",
      body: "",
      timeContext: { kind: "calendar_date" },
      deletedAt: null,
      createdAt: first.createdAt,
      updatedAt: first.createdAt
    });
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [first, second] });
    vi.spyOn(researchRepository, "listEventsByCase").mockResolvedValue([record]);
    vi.spyOn(researchRepository, "listResearchNotesByCase").mockResolvedValue([]);
    mockResearchJournalSnapshot(caseRecord.id, [record]);
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${first.id}?view=research&event=${record.id}`);

    render(<ChartPage caseId={caseRecord.id} revisionId={first.id} />);

    const alert = await screen.findByRole("alert", { name: "地址或深链参数未全部接受" });
    expect(alert.textContent).toContain("属于其他 Revision");
    expect(alert.textContent).toContain("不会在当前修订近似定位");
    expect(screen.getAllByRole("alert")).toHaveLength(1);
    const journalError = screen.getByText("无法定位事件").closest(".inline-error");
    expect(journalError?.getAttribute("role")).toBeNull();
    expect(journalError?.getAttribute("data-parent-announcement")).toBe("present");
    expect(document.querySelector(".event-card--selected")).toBeNull();
  });

  it("回收站案例显示只读状态并禁用派生入口", async () => {
    const revision = await revisionFor(input);
    const caseRecord: CaseRecord = {
      schemaVersion: "1.0.0",
      id: revision.caseId,
      alias: "回收站命盘",
      tags: [],
      notes: "",
      createdAt: revision.createdAt,
      updatedAt: revision.createdAt,
      latestRevisionId: revision.id,
      revisionCount: 1,
      recordVersion: 2,
      favorite: false,
      deletedAt: revision.createdAt
    };
    vi.spyOn(caseRepository, "getCase").mockResolvedValue({ caseRecord, revisions: [revision] });
    window.history.replaceState({}, "", `/cases/${caseRecord.id}/revisions/${revision.id}`);

    render(<ChartPage caseId={caseRecord.id} revisionId={revision.id} />);

    expect(await screen.findByText("案例已在回收站")).toBeTruthy();
    expect(screen.getByRole("button", { name: "由此修订派生新版" })).toHaveProperty("disabled", true);
    expect(screen.queryByRole("link", { name: "由此修订派生新版" })).toBeNull();
  });
});
